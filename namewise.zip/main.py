import gui.pages.start_page
import gui.pages.parse_page
import gui.pages.progress_page
import gui.pages.folder_page
import gui.pages.summary_page
from gui.wizard import run

if __name__ == "__main__":
    run()