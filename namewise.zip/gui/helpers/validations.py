import os, re

def validate_folder(path: str) -> bool:
    """
    Returns True if path is an existing directory containing at least one .tif file.
    """
    if not os.path.isdir(path):
        return False
    try:
        entries = os.listdir(path)
    except Exception:
        return False
    return any(fname.lower().endswith('.tif') for fname in entries)

def validate_spreadsheet(path: str) -> bool:
    """
    Returns True if path is an existing file ending in .xlsx, .xls, or .csv.
    """
    if not os.path.isfile(path):
        return False
    return path.lower().endswith(('.xlsx', '.xls', '.xlsm', '.csv'))

def validate_blend_name(name: str) -> bool:
    """
    Empty is OK. Otherwise must not contain any forbidden characters for filenames:
      < > : " / \ | ? * ;
    """
    if not name:
        return True

    forbidden = set('<>:"/\\|?*;')
    return not any(ch in forbidden for ch in name)

def validate_volume(vol: str) -> bool:
    """
    Empty is OK. Otherwise must be one of:
      - a number (integer or decimal) + optional space + letters
      - a multiplication expression like "NxM" (e.g. "12x1") + optional space + letters

    Examples: "2 oz", "50gal", "10.5kg", "6000 gal", "12x1 L"
    """
    if not vol:
        return True

    # \d+(?:\.\d+)?      → integer or decimal (e.g. "10" or "10.5")
    # (?:[xX]\d+(?:\.\d+)?)* → zero or more "x<number>" segments (e.g. "x1", "x2.5")
    # \s*[A-Za-z]+       → optional space then unit letters
    pattern = r"^\d+(?:\.\d+)?(?:[xX]\d+(?:\.\d+)?)*\s*[A-Za-z]+$"
    return bool(re.fullmatch(pattern, vol))
